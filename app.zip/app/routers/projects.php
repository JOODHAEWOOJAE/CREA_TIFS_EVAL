<?php

use \App\Controllers\ProjectsController;

include_once '../app/controllers/projectsController.php';

switch ($_GET['projects']):
    case 'show':
        ProjectsController\showAction($connexion, $_GET['id']);
        break;

    default:
        ProjectsController\indexAction($connexion);
        break;
endswitch;